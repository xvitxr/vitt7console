﻿namespace vitt7console.ConsoleUI
{
    public class Input
    {
        public object? Instance = new();

        public void NewLine<Message>(Message message, bool Input = true)
        {
            if (!string.IsNullOrEmpty(message.ToString()))
                Console.Write(message);
            Instance = (Input) ? Console.ReadLine() : Instance;
            if (Input) ReadLine();
        }

        public void ReadLine()
        {
            foreach (Commands.MakeNew command in Commands.General.CommandsRegistry)
            {
                command.Method();
            }
        }
    }
}
