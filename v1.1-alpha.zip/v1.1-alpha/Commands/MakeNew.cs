﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vitt7console.Commands
{
    public class MakeNew
    {
        public string Reference { 
            get => Reference; 
            set
            {
                if (Reference.Contains(' '))
                    Reference.Remove(' ');
                if (string.IsNullOrEmpty(Reference))
                    Reference = "None";
            }
        }
        public string Name { get; set; } = "None";
        public string Description { get; set; } = "None";
        public string Author { get; set; } = "None";

        public delegate void _method();
        public _method? Method { get; set; } = null;
        public bool BuiltIn { get; set; }
        public bool Accessible { get; set; }
        public bool Global { get; set; }


    }
}
