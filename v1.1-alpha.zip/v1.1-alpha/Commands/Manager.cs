﻿using vitt7console.ConsoleUI;

namespace vitt7console.Commands
{
    public class Manager
    {
        public Manager()
        {
            General.CommandsRegistry.Add(new MakeNew()
            {
                Name = "General Input Manager",
                Description = "Draws a new input line when input is empty or null",
                Reference = "gimgr",
                Author = "@vittSeven",
                Method = () =>
                {
                    Console.WriteLine("test");
                    if (ConsoleUI.General.GlobalInput.Instance.ToString() == "")
                        ConsoleUI.General.GlobalInput.NewLine(">>");
                },
                Accessible = false,
                Global = true
            });
        }
    }
}
