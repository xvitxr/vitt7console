﻿namespace v7con.ConsoleUI
{
    public class InPContent
    {
        public InPContent()
        {
            CGPC();
        }

        #region CGP

        // Common Global Parser //

        public static object? CGP = new();
        public static object[]? CGP_PERSPACE = new object[] { };
        private void CGPC()
        {
            InputParser.Parsers.Add(new InputParser()
            {
                Reference = "global",
                Description = "Default Input Parser, simple parsing, Console.ReadLine() => CGP",
                ParserMethod = () =>
                {
                    Console.Write(">>");
                    CGP = Console.ReadLine();
                    CGP_PERSPACE = CGP.ToString().Split(' ');
                },

                InputProcessMethod = () =>
                {
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                            cmd.Method();
                    }
                    General.IM.NewLine("");
                }
            });
        }

        #endregion

    }
}
