﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI.Debug
{
    internal class Log
    {
        private static int index = 0;
        public static string GetMessage( string? owner, string? msg, short? id = 0, short? type = 0)
        {
            index++;
            
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;

            string idmsg = "", tpmsg = "";

            switch (type)
            {
                case 0:
                    tpmsg = "TEMPORARY";
                    break;
                case 1:
                    tpmsg = "PERMANENT";
                    break;
            }

            switch (id)
            {
                case 0:
                     idmsg = "INFO";
                    break;
                case 1:
                    idmsg = "WARNING";
                    break;
                case >= 2:
                    idmsg = "ERROR";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                return ($"[{index} ({tpmsg}) {idmsg}]: {msg}");
            return ($"[{index} {tpmsg} {idmsg} on \"{owner}\"]: {msg}");

        }

        public static string GetMessageShort(string? owner, string? msg, short? id = 0, short? type = 0)
        {
            index++;
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;

            string idmsg = "", tpmsg = "";

            switch (type)
            {
                case 0:
                    tpmsg = "T.E";
                    break;
                case 1:
                    tpmsg = "P.E";
                    break;
            }

            switch (id)
            {
                case 0:
                    idmsg = "i";
                    break;
                case 1:
                    idmsg = "w";
                    break;
                case >= 2:
                    idmsg = "e";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                return ($"[{idmsg}]: {msg}");
            return ($"[{tpmsg} {idmsg}] {owner}: {msg}");
        }
    }
}
