﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI.Debug
{
    internal partial class ExceptionHandler
    {
        public ExceptionHandler(Exception e, string info)
        {
            if (string.IsNullOrEmpty(info))
                info = "Something went wrong";
            Console.WriteLine(info);
            Console.Write("[i] [q] [x]>> ");
            Query:
            var query = Console.ReadLine();
            switch (query)
            {
                case "i":
                    Console.WriteLine(e.ToString());
                        break;
                case "x":
                    Environment.Exit(0);
                    break;
                case "q":
                    break;
                default:
                    goto Query;
            }
        }
    }
}
