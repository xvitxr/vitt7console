﻿using System;
using v7con.ConsoleUI;
using v7con.Additional;
using v7con.ConsoleUI.Debug;

namespace v7con
{
    public class Program
    {
        // Variáveis do sistema / System variables
        public static string
            name = "vitt7console",
            version = "v1.2.2",
            author = "@VittSeven (GitHub)",
            about = $"{name} [version {version}] by {author}";

        static void Main()
        {
            try
            {
                new General();
            }
            catch (Exception e)
            {
                new ExceptionHandler(e, Log.GetMessage("SYSTEM", "Something went wrong", 2, 1));
                Console.Write("Press enter to continue...");
                Console.ReadLine();
            }
        }
    }
}
