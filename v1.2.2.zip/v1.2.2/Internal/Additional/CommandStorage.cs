﻿using System;
using v7con;
using v7con.ConsoleUI;
using v7con.ConsoleUI.Debug;

namespace v7con.Additional
{
    public class CommandStorage
    {
        public CommandStorage()
        {
            #region NLM

            // New Line Manager //

            Command.CommandsRegistry.Add(new Command()
            {
                Name = "NLM",
                Reference = "nlm",
                Author = Program.author,
                System = true,
                Description = "Manage the input line spawning (Cannot be called)",
                Method = () =>
                {
                    if (string.IsNullOrEmpty(InPContent.CGP.ToString()))
                        General.IM.NewLine("");
                    else
                    {
                        int index = 0;
                        foreach (Command cmd in Command.CommandsRegistry)
                        {
                            if (InPContent.CGP_PERSPACE[0].Equals(cmd.Reference) && !cmd.System)
                                index++;
                        }
                        if (index == 0)
                            Console.WriteLine(Log.GetMessageShort("CGP", $"\"{InPContent.CGP}\" does not exist."));
                    }
                }
            });


            #endregion

            #region Help Command

            // Help command //

            Command.CommandsRegistry.Add(new Command()
            {
                Name = "Help command",
                Method = () => Self(),
                Author = Program.author,
                Description = "Shows informations about commands",
                Reference = "help",
                HELP_FullDescription =
                "Shows information about a specified command.\n\n" +
                "\t\t\thelp [command reference]\n\n" +
                "\t\t [command reference]: All commands have references, if not, the command its not complete.\n\n" +
                "You can use only 'help', to see all commands.\n"
            });

            static void Self()
            {
                string[]? helpArgs = InPContent.CGP.ToString().Split(' ');
                if (helpArgs.Length == 1 && helpArgs[0] == "help")
                {
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                        if (cmd.Public)
                            Console.WriteLine($"{cmd.Reference.ToUpper()} - {cmd.Author}" +
                                $" \t {cmd.Description}");
                    }
                }
                else if (helpArgs.Length != 1 && helpArgs[0] == "help"
                    && !string.IsNullOrEmpty(helpArgs[1]))
                {
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                        if (helpArgs[1] == cmd.Reference && cmd.Public)
                        {
                            if (string.IsNullOrEmpty(cmd.HELP_FullDescription))
                                Console.WriteLine(Log.GetMessageShort("Help List Manager",
                                    $"{cmd.Reference} don't have a full description.", 1));
                            else Console.WriteLine(cmd.HELP_FullDescription);
                            Console.Write("Press enter to continue...");
                            Console.ReadLine();
                            return;
                        }
                    }
                    Console.WriteLine(Log.GetMessageShort("Help List Manager", $"\"{helpArgs[1]}\" don't exist.", 2));
                }
                else if (InPContent.CGP.Equals("help "))
                {
                    Console.WriteLine(Log.GetMessageShort("Help List Manager", $"Incomplete command.", 2));
                }
            }

            #endregion

            #region Exit

            // Exit Command //

            Command.CommandsRegistry.Add(new Command()
                {
                    Name = "Exit",
                    Description = "Exits the program.",
                    Reference = "exit",
                    Author = Program.author,
                    HELP_FullDescription = "Exits the program\n\n" +
                    "\texit\n",
                    Method = () => { if (InPContent.CGP.Equals("exit")) Environment.Exit(0); }
                });

            #endregion
        }
    }
}
