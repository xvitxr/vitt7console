﻿using System;
using v7con;
using Spectre.Console;
using v7con.Data;
using v7con.ConsoleUI;
using v7con.Data.etc;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;

namespace v7con
{
    public partial class Command
    {
        public bool HELP_AutoGetHelpArg { get; set; } = true;
        public string? HELP_FullDescription { get; set; }
        public bool HELP_Public { get; set; } = true;
        public bool NLM_System { get; set; } = false;
    }
}

namespace v7con.ConsoleUI.Input
{
    public partial class InputParser
    {
        public string? HELP_ParserMethodName { get; set; } = "Parser()";
        public string? HELP_InputProcessMethodName { get; set; } = "InputProcessMethod()";
    }
}

namespace v7con.Data
{
    public class Commands
    {
        public static object GLOBALDIR = Environment.GetEnvironmentVariable("USERPROFILE")!;
        public Commands()
        {
            #region NLM

                // New Line Manager //
                int timeswrong = 0;
            Command.CommandsRegistry.Add(new Command()
            {
                Name = "NLM",
                Reference = "nlm",
                Author = Program.Essentials.Author,
                HELP_Public = false,
                NLM_System = true,
                Description = "Manage the input line spawning (Cannot be called)",
                HELP_FullDescription = "Empty input = Main.IM.NewLine(), 5 wrong inputs = Message, General wrong inputs = Message (Cannot be called)",
                Method = () =>
                {
                    if (string.IsNullOrEmpty(InputParsers.CGP!.ToString()))
                        Main.IM.NewLine("");
                    else
                    {
                        
                        string[] x = InputParsers.CGP.ToString()!.Split(' ');
                        int index = 0;
                        foreach (Command cmd in Command.CommandsRegistry)
                        {
                            if (x[0].Equals(cmd.Reference) && !cmd.NLM_System)
                                index++;
                        }

                        if (index == 0)
                        {
                            if (timeswrong++ == 5)
                            {
                                timeswrong = 0;
                                Console.WriteLine("To show a list of the commands, type \"help\" ;]");
                                return;
                            }
                            Log.MessageShort("CGP", $"\"{InputParsers.CGP}\" does not exist.");
                        }
                    }
                }
            });


            #endregion

            #region Help Command

            // Help command //

            Command.CommandsRegistry.Add(new Command()
            {
                Name = "Help Command",
                Method = () => Self(),
                Author = Program.Essentials.Author,
                Description = "Shows informations about commands",
                Reference = "help",
                HELP_FullDescription =
                "HELP COMMAND:\n\n" +
                "\thelp [arg] [command reference]\n\n" +
                "[arg]:\n/A for all commands\n" +
                "/P for all publics commands\n" +
                "/H for all non-public commands" +
                "\n/IP to show Input Parsers\n\n" +
                "[command reference]: Requested command\n\n" +
                "\thelp\nShow all public commands automatically\n\n" +
                "\t help [command reference]\n\n" +
                "Show the requested [command reference]\n\n(GLOBAL) [command reference] /?: shows the command help description."
            });

            static void Self()
            {
                // Commands Table Render //

                Table commandsTable = new();
                commandsTable.Title = new TableTitle("[bold underline cyan]Current Command Instances[/]");
                commandsTable.AddColumn("[bold underline blue]Name[/]");
                commandsTable.AddColumn("[bold underline white]Author[/]");
                commandsTable.AddColumn("[bold underline white]Reference[/]");
                commandsTable.AddColumn("[bold underline white]Description[/]");
                commandsTable.AddColumn("[bold underline yellow]System?[/]");

                // Input Parsers Table Render // 

                Table parsersTable = new();
                parsersTable.Title = new TableTitle("[bold underline cyan]" +
                    "Current Input Parser Instances[/]");
                parsersTable.AddColumn("[bold underline white]Reference[/]");
                parsersTable.AddColumn("[bold underline blue]Parser Method[/]");
                parsersTable.AddColumn("[bold underline blue]Input Process Method[/]");
                parsersTable.AddColumn("[bold underline white]Description[/]");

                string[]? helpArgs = InputParsers.CGP!.ToString()!.Split(' ',3);

                if (helpArgs[0] == "help")
                {
                    if (helpArgs.Length >= 2 && !string.IsNullOrEmpty(helpArgs[1]))
                    {
                        if (helpArgs[1] == "/P")
                        {
                            if (helpArgs.Length <= 2 && helpArgs[1] == "/P")
                                Option("/P");
                            else if (helpArgs.Length >= 2 && helpArgs[1] == "/P"
                                && !string.IsNullOrEmpty(helpArgs[2]))
                                new GetHelp(helpArgs[2], "/P");
                        }
                        else if (helpArgs[1] == "/A")
                        {
                            if (helpArgs.Length <= 2 && helpArgs[1] == "/A")
                                Option("/A");
                            else if (helpArgs.Length >= 2 && helpArgs[1] == "/A"
                                && !string.IsNullOrEmpty(helpArgs[2]))
                                new GetHelp(helpArgs[2], "/A");
                        }
                        else if (helpArgs[1] == "/H")
                        {
                            if (helpArgs.Length <= 2 && helpArgs[1] == "/H")
                                Option("/H");
                            else if (helpArgs.Length >= 2 && helpArgs[1] == "/H"
                                && !string.IsNullOrEmpty(helpArgs[2]))
                                new GetHelp(helpArgs[2], "/H");
                        }
                        else if (helpArgs[1] == "/IP")
                        {
                            foreach (InputParser parser in InputParser.Parsers)
                            {
                                parsersTable.AddRow($"[bold white]{parser.Reference}[/]",
                                    $"[bold underline cyan]{parser.HELP_ParserMethodName}[/]",
                                    $"[bold underline cyan]{parser.HELP_InputProcessMethodName}[/]",
                                    $"[white]{parser.Description}[/]");
                            }
                            AnsiConsole.Write(parsersTable);
                        }
                        else
                        {
                            foreach (Command cmd in Command.CommandsRegistry)
                            {
                                if (cmd.Reference == helpArgs[1] && cmd.HELP_Public)
                                {
                                    new GetHelp(helpArgs[1], "/P");
                                    return;
                                }
                            }
                            Log.MessageShort("Get Help", $"\"{helpArgs[1]}\" was not recogzine as [arg] or [command reference]");
                        }
                    }
                    else Option();
                }

                void Option(string display = "DEF") // help [arg]
                {
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                        if (cmd.HELP_Public && display == "DEF")
                        {
                            commandsTable.AddRow(
                            $"[bold blue]{cmd.Name}[/]",
                            $"[white]{cmd.Author}[/]",
                            $"[bold underline blue]{cmd.Reference!.ToUpper()}[/]",
                            $"[white]{cmd.Description}[/]",
                            $"{((cmd.NLM_System) ? "[bold red]Yes[/]" : "[bold green]No[/]")}");
                            commandsTable.Caption = new TableTitle($"To obtain information about an specific command," +
                                $" type help [[command reference]]");
                        }

                        else if (cmd.HELP_Public && display == "/P")
                        {
                            commandsTable.AddRow(
                            $"[bold blue]{cmd.Name}[/]",
                            $"[white]{cmd.Author}[/]",
                            $"[bold underline blue]{cmd.Reference!.ToUpper()}[/]",
                            $"[white]{cmd.Description}[/]",
                            $"{((cmd.NLM_System) ? "[bold red]Yes[/]" : "[bold green]No[/]")}");
                            commandsTable.Caption = new TableTitle($"To obtain information about an specific command," +
                                $" type help {display} [[command reference]]");
                        }

                        else if (display == "/A")
                        {
                            commandsTable.AddRow(
                                $"[bold blue]{cmd.Name}[/]",
                                $"[white]{cmd.Author}[/]",
                                $"[bold underline blue]{cmd.Reference!.ToUpper()}[/]",
                                $"[white]{cmd.Description}[/]",
                                $"{((cmd.NLM_System) ? "[bold red]Yes[/]" : "[bold green]No[/]")}");
                            commandsTable.Caption = new TableTitle($"To obtain information about an specific command," +
                                $" type help {display} [[command reference]]");
                        }

                        else if (!cmd.HELP_Public && display == "/H")
                        {
                            commandsTable.AddRow(
                            $"[bold blue]{cmd.Name}[/]",
                            $"[white]{cmd.Author}[/]",
                            $"[bold underline blue]{cmd.Reference!.ToUpper()}[/]",
                            $"[white]{cmd.Description}[/]",
                            $"{((cmd.NLM_System) ? "[bold red]Yes[/]" : "[bold green]No[/]")}");
                            commandsTable.Caption = new TableTitle($"To obtain information about an specific command," +
                                $" type help {display} [[command reference]]");
                        }
                    }
                    AnsiConsole.Write(commandsTable);
                }
            }


            #endregion

            #region Change Directory

            // Change Directory Command //

            Command.CommandsRegistry.Add(new Command()
            {
                Name = "Change Directory Command",
                Reference = "cd",
                Description = "Manages the current directory",
                HELP_FullDescription = "" +
                "Changes the system directory\n" +
                "       cd [dir]\n" +
                "           [dir]: an valid directory\n" +
                "       cd\n" +
                "           Shows current directory",
                Method = () => cdcommand()
            });

            static void cdcommand()
            {
                var x = InputParsers.CGP!.ToString()!.Split(' ', 2);
                var arg1 = x[0];
                

                if (arg1 == "cd")
                {
                    if (x.Length == 2)
                    {
                        var arg2 = x[1];
                        foreach (string dir in Directory.GetDirectories(GLOBALDIR.ToString()!))
                        {
                            string subdir = dir.Replace(Path.GetDirectoryName(dir)
                                + Path.DirectorySeparatorChar, "");
                            
                            Console.WriteLine(subdir);
                            if (arg2 == subdir)
                            {
                                arg2 = $@"{GLOBALDIR}\{subdir}";
                                break;
                            }
                        }
                        
                        if (!Directory.Exists(arg2))
                        {
                            Log.MessageShort("CD MANAGER", "Inexistent directory.", 2);
                            Main.IM.NewLine("");
                        }
                        else
                            GLOBALDIR = arg2.Replace("/", @"\");
                    }
                    else
                        Console.WriteLine(GLOBALDIR);
                }
            }

        #endregion

            #region Dir Tree List

            // Directory Tree List Viewer
            Command.CommandsRegistry.Add(new Command()
            {
                Name = "Directory Tree List Viewer",
                Reference = "dir",
                HELP_FullDescription = "Shows directories and files on the current global dir.\n\n" +
                "\tdir\n",

                Description = "Manages the directory getting on GLOBALDIR",
                Method = () => dirmethod()
            });

            static void dirmethod()
            {
                var x = InputParsers.CGP!.ToString()!.Split(' ', 2);

                if (x[0] == "dir")
                {
                    DirectoryInfo dirinfo = new(GLOBALDIR.ToString()!);
                    var treerenderdir = new Tree($"\n{GLOBALDIR}");
                    int dirquant = 0;
                    foreach (DirectoryInfo dir in dirinfo.GetDirectories())
                    {
                        dirquant++;
                        treerenderdir.AddNode($"{dir.Name.SpectreSafe()}");
                    }
                    AnsiConsole.Write(treerenderdir);
                    if (dirquant == 0)
                        Console.WriteLine("No dirs to look here!");

                    int filequant = 0;

                    // Files 

                    long filetotalsize = 0;

                    Tree treerenderfiles = new("\nFiles");
                    foreach (FileInfo file in dirinfo.GetFiles())
                    {
                        filetotalsize += file.Length;
                        filequant++;
                        treerenderfiles.AddNode($"{file.Name} \t<{file.CreationTime}>");
                    }
                    AnsiConsole.Write(treerenderfiles);
                    if (filequant == 0)
                        Console.WriteLine("No files to look here!");
                    Console.WriteLine($"\n\tA total of...\n\t\t{dirquant}" +
                        $" dir(s)\n\t\t{filequant} file(s), {Math.Round(Convert.ToDecimal(filetotalsize) / 1000000)} " +
                        $"Megabytes ({filetotalsize} bytes)\n");
                }
            }

            #endregion
            
            #region Exit

            // Exit Command //

                Command.CommandsRegistry.Add(new Command()
                {
                    Name = "Exit",
                    Description = "Exits the program.",
                    Reference = "exit",
                    Author = Program.Essentials.Author,
                    HELP_FullDescription = "Exits the program\n\n" +
                    "\texit\n",
                    Method = () => { if (InputParsers.CGP!.Equals("exit")) Environment.Exit(0); }
                });

            #endregion
        }
    }
}