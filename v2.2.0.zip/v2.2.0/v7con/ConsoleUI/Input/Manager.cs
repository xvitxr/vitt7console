﻿using v7con.Data;
using v7con.Data.etc;
using v7con.ConsoleUI;
using v7con.ConsoleUI.Debug;


namespace v7con.ConsoleUI.Input
{
    public partial class Manager
    {
        public virtual void NewLine<T>(T msg,string inputparser = "global")
        {
            if (!string.IsNullOrEmpty(msg.ToString()))
                Console.Write(msg);
            foreach (InputParser parse in InputParser.Parsers)
                parse.ParserMethod();
            foreach (InputParser parser in InputParser.Parsers)
            {
                if (inputparser == parser.Reference)
                    parser.InputProcessMethod();
                else
                    NewLine(Log.GetMessage(this.ToString(), $"\"{inputparser}\" don't exist.", 2));
            }
            
                
        }
    }
}
