﻿using Spectre.Console;
using v7con.Data.etc;

namespace v7con.ConsoleUI.Debug
{
    internal partial class ExceptionHandler
    {
        public ExceptionHandler(Exception e, string info)
        {
            if (string.IsNullOrEmpty(info))
                info = "Something went wrong";

            Query:

            var query = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                .Title(info.SpectreSafe())
                .AddChoices(new[]
                {
                    "info", "exit", "quit"
                }));

            switch (query)
            {
                case "info":
                    Console.WriteLine(e.ToString());
                    break;
                case "exit":
                    Environment.Exit(0);
                    break;
                case "quit":
                    break;
                default:
                    goto Query;
            }

        }
    }
}
