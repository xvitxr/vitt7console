﻿using System;
using Spectre.Console;
using v7con.Data;
using v7con.ConsoleUI;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;



namespace v7con
{

    public class Program
    {
        // Variáveis do sistema / System variables
        public struct Essentials
        {
            public static string
                Name = "vitt7console",
                Version = "v2.1.1",
                Author = "@VittSeven (GitHub)",
                About = $"{Name} [version {Version}] by {Author}";
        }

        static void Main()
        {
            try
            {
                Main MainInstance = new();
            }
            catch (Exception e)
            {
                _ = new ExceptionHandler(e, Log.GetMessage("SYSTEM", "An unexpected ", 2));
                Console.Write("Press enter to continue...");
                Console.ReadLine();
            }
        }


    }
}
