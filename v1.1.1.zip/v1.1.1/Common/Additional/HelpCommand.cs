﻿using System;
using v7con.ConsoleUI;
using v7con.Common;

namespace v7con.Common.Additional
{
    public class HelpCommand
    {
        
        public static List<HelpCommand> HelpList = new();

        public static void Command()
        {
            
            if (InputManager.RawInput.ToString().Contains(' '))
            {
                string[] x = InputManager.RawInput.ToString().Split(' ');
                if (x[0].Equals("help"))
                {
                    if (!string.IsNullOrEmpty(x[1]))
                    {
                        foreach (Common.Command command in Common.Command.CommandsRegistry)
                        {
                            if (x[1] == command.Reference)
                            {
                                if (string.IsNullOrEmpty(command.FullDescription))
                                    Console.WriteLine("WARNING: This command doesn't have a Help Description");
                                Console.WriteLine(command.FullDescription);
                                Console.Write("Press enter to continue...");
                                Console.ReadLine();
                                break;
                            }
                        }
                    }
                }
                else
                {
                    foreach (Common.Command command in Common.Command.CommandsRegistry)
                    {
                        Console.WriteLine($"{command.Reference.ToUpper()}\t\t\t{command.Description}");
                    }
                }
            }
            else
            {
                foreach (Common.Command command in Common.Command.CommandsRegistry)
                {
                    Console.WriteLine($"{command.Reference.ToUpper()}\t\t\t{command.Description}");
                }
            }
        }
    }


}
