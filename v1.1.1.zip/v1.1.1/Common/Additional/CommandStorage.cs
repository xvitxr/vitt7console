﻿using System;
using v7con.Common;
using v7con.Additional;
using v7con.ConsoleUI;

namespace v7con.Additional
{
    public class CommandStorage
    {
        public CommandStorage()
        {
            #region NLM
            Common.Command.CommandsRegistry.Add(new Common.Command()
            {
                Name = "NLM",
                Reference = "nlm",
                Description = "Manage the input line spawning (Cannot be called)",
                Method = () =>
                {
                    if (string.IsNullOrEmpty(InputManager.RawInput.ToString()))
                        InputManager.NewLine("");
                }
            });
            #endregion

            #region Help Command
            // Help command //
            Command.CommandsRegistry.Add(new Common.Command()
            {
                Name = "Help command",
                Method = () => Common.Additional.HelpCommand.Command(),
                Author = Program.author,
                Description = "Shows informations about commands",
                Reference = "help",
                FullDescription =
                "Shows information about a specified command.\n\n" +
                "\t\t\thelp [command reference]\n\n" +
                "\t\t [command reference]: All commands have references, if not, the command its not complete.\n\n" +
                "You can use only 'help', to see all commands.\n"
            });
            #endregion
        }
    }
}
