﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.Common
{
    public partial class Command
    {
        public string? FullDescription { get; set; }
    }
}
