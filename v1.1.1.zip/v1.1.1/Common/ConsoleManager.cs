﻿using System;
using System.Collections.Generic;


namespace v7con.Common
{
    public class ConsoleManager
    {



        public static void RunAllCommands()
        {
            foreach (Command command in Command.CommandsRegistry)
            {
                command.Method();
            }       
        }


    }
}
