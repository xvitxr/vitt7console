﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.Common
{

    public partial class Command
    {
        public static List<Command> CommandsRegistry = new List<Command>();

        public string? Name { get; set; } = "None";

        public string? Description { get; set; } = "None";

        public string? Author { get; set; } = Program.author;

        public string? Reference { get; set; }

        public delegate void method();

        public method? Method { get; set; }

    }

}
