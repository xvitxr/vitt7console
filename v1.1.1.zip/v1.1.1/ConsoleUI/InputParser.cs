﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI
{
    public class InputParser
    {
        public static List<InputParser> InputParsersRegistry = new List<InputParser>();

        public delegate void method();
        public method? Method { get; set; }
    }
}
