﻿using System;
using v7con.Additional;

namespace v7con.ConsoleUI
{
    public class General
    {
        public General()
        {
            new InputParserMethodStorage();
            new CommandStorage();
            Console.WriteLine(Common.Program.about);
            InputManager.NewLine("");
        }
    }
}
