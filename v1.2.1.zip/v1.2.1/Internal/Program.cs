﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con
{
    public class Program
    {
        // Variáveis do sistema / System variables
        public static string
            name = "vitt7console",
            version = "v1.2.1",
            author = "@VittSeven (GitHub)",
            about = $"{name} [version {version}] by {author}";

        static void Main()
        {
            new ConsoleUI.General();
        }
    }
}
