﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI
{
    internal class Debug
    {
        private static int index = 0;
        public static string GetLogMessage(string? owner = "SYSTEM", string? msg = "empty", short? id = 0)
        {
            index++;
            
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;

            string idmsg = "";

            switch (id)
            {
                case 0:
                     idmsg = "INFO";
                    break;
                case 1:
                    idmsg = "WARNING";
                    break;
                case 2:
                    idmsg = "ERROR";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                return ($"[{idmsg} INDEX({index})]: {msg}");
            return ($"[{idmsg} on \"{owner}\"]: {msg} [INDEX({index})]");

        }
    }
}
