﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI
{
    // Parecido com "Command.cs", só que são informações 
    // sobre os "parsers" e "parsersinputprocesser" 
    
    // Similar with "Command.cs", but it is just the 
    // information about the "parsers" and "parsersinputprocesser" 

    public partial class InputParser
    {
        public static List<InputParser> Parsers = new();
        public delegate void method();
        public string? Reference { get; set; }
        public string? Description { get; set; }
        public method? ParserMethod { get; set; } /* Método do parser / parser method
        
        Parser:
        São instâncias desta classe que definem como o output
        dos inputs vão ser gerenciados.

        They are instances of this class that defines how the output
        of the inputs will be managed.
        
        */

        public method? InputProcessMethod { get; set; } /* Método do parserinputprocess / parserinputprocess method
        
        Parserinputprocess:
        Vão definir como as instâncias da classe "Comamnd.cs" vão ser executados.

        Defines how the instances of the class "Command.cs" will be managed.

        */
    }
}
