﻿using System;
using v7con.Additional;

namespace v7con.ConsoleUI
{
    public class General
    {
        public static InputManager IM = new();
        public General()
        {
            new InPContent();
            new CommandStorage();
            Console.WriteLine(Program.about);
            IM.NewLine("");
        }
    }
}
