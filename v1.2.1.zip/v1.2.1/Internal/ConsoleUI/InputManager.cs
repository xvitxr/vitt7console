﻿namespace v7con.ConsoleUI
{
    public partial class InputManager
    {
        public static InputManager InPInstance = new();
        public virtual void NewLine<T>(T msg,string inputparser = "global")
        {
            if (!string.IsNullOrEmpty(msg.ToString()))
                Console.Write(msg);
            Console.Write(">>");
            foreach (InputParser parser in InputParser.Parsers)
            {
                if (inputparser == parser.Reference)
                {
                    parser.ParserMethod();
                    parser.InputProcessMethod();
                }
            }
            NewLine(Debug.GetLogMessage(this.ToString(), $"\"{inputparser}\" don't exist.", 2));
                
        }
    }
}
