﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con
{
    public partial class Command
    {
        public string? HELP_FullDescription { get; set; }
        public bool Public { get; set; } = true;

        public bool System { get; set; } = false;
    }
}
