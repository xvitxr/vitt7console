﻿using System;
using System.Collections.Generic;

/* Was used on v1.1.1 (sort of), not anymore.
Foi usado na v1.1.1 (mais ou menos), não vai ser usado mais.

namespace v7con
{
    public class ConsoleManager
    {
        public static void RunAllCommands()
        {
            foreach (Command command in Command.CommandsRegistry)
            {
                command.Method();
            }       
        }


    }
}
*/