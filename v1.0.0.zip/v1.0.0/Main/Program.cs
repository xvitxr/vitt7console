﻿using System;
using vitt7console.Commands;
using vitt7console.Console;


namespace vitt7console.Main
{
    public class Essentials
    {
        public static string buildStatus = "alpha";
        public static (string Long, string Short) name =
            ("vitt7console",
            "v7con");
        public static (string Long, string Short) version = 
            ($"{buildStatus}-{version.Short}",
            "1.0.0");
        public static (string Long, string Short) about = 
            ($"{name.Long} [ver: {version.Long}] made by @vittSeven on github",
            $"{name.Short} [{version.Short}]");

        static void Main()
        {
            new Log();
            new Manager();
        }
    }
}
