﻿using System;
using vitt7console.Main;
using vitt7console.Commands;

namespace vitt7console.Console
{
    public class Manager
    {
        public static bool AlreadyCalledManager = false;
        public static object rawGInput;
        public static object[] globalInput = new object[] { 0 };
        
        public static void Input<Message>(Message message)
        {
            if (Convert.ToString(message) != "" || message != null)
                System.Console.Write(message);
            rawGInput = System.Console.ReadLine();
            globalInput = Convert.ToString(rawGInput).Split(' ');
            Output();
        }

        private static void Output()
        {
            foreach (Register command in Register.CommandsRegistry)
            {
                if (command.Access)
                    command.CurrMethod();
            }
            Input($"\"{globalInput[0]}\" is not a internal command\n>>");
        }

        public Manager()
        {
            if (!AlreadyCalledManager)
            {
                AlreadyCalledManager = true;
                System.Console.Title = Essentials.name.Long;
                System.Console.WriteLine($"{Essentials.about.Long}\n");
                Input(">>");
            }
        }

        public static bool Execute(object command, object[] args = null)
        {
            if (globalInput[0].Equals(command))
            {
                if (args != null)
                {
                    int index = 1;
                    foreach (object arg in args)
                    {
                        if (globalInput[index] == arg)
                        {
                            return true;
                        }
                        index++;
                    }
                    return false;
                }
                else
                    return true;
            }
            else
                return false;
        }
        
    }
}
