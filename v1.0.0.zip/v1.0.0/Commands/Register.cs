﻿using System.Collections.Generic;

namespace vitt7console.Commands
{
    public class Register
    {
        public static List<Register> CommandsRegistry = new List<Register>();
        public string Name { get; set; }
        public string Info { get; set; }
        public string Syntax { get; set; }
        public string Author { get; set; }
        public string Reference { get; set; }
        public delegate void Method();
        public Method CurrMethod{ get; set; }
        public bool BuiltIn { get; set; }
        public bool Access { get; set; } 

        public Register()
        {
            if (Name == null || Name == "")
                Name = "None";
            if (Info == null || Info == "")
                Info = "None";
            if (Syntax == null || Syntax == "")
                Syntax = "None";
            else  if (Syntax != null || Syntax != "")
                Syntax = $"[{Syntax}]"; 
            if (Author == null || Author == "")
                Author = "None";
            if (Reference == null || Reference == "")
                Reference = "None";
        }
    }
}
