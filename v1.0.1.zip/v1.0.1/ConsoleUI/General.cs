﻿using Spectre.Console;
namespace vitt7console.ConsoleUI
{
    public class General
    {
        public static Input GlobalInput = new();
        public static void Setup()
        {
            Console.Title = Main.Essentials.name.Long;
            Console.WriteLine(Main.Essentials.about.Long);
            GlobalInput.NewLine(">>");
        }
    }
}
