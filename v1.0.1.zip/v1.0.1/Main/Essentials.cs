﻿namespace vitt7console.Main
{
    public class Essentials
    {
        public static string buildStatus = "alpha";
        public static (string Long, string Short) name =
            ("vitt7console",
            "v7con");
        public static string versionLong = $"{buildStatus}-{versionShort}";
        public static string versionShort = "1.0.0";
        public static (string Long, string Short) about = 
            ($"{name.Long} [ver: {versionLong}] made by @vittSeven on github",
            $"{name.Short} [{versionShort}]");

        static void Main() 
        { 
            ConsoleUI.General.Setup(); 
        }
    }
}
