﻿using System.Collections.Generic;

namespace vitt7console.Commands
{
    public static class General
    {
        public static List<MakeNew> CommandsRegistry = new List<MakeNew>();
    }
}
