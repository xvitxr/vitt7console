﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.Container.Data
{
    public static class CGP
    {
        public static string SpectreSafe(this string Value)
        {
            return Value.Replace("[", "[[").Replace("]", "]]");
        }
    }
}
