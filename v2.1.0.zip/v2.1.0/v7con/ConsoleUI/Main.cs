﻿using System;
using v7con.Data.etc;
using Spectre.Console;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;
using v7con.Data; 

namespace v7con.ConsoleUI
{
    public class Main
    {
        public static Manager IM = new();
        public Main()
        {
            ConsoleLoad();
            AnsiConsole.MarkupLine($"[underline cyan]" +
                $"{Program.about.SpectreSafe()}[/]\n");
            IM.NewLine("");
        }

        private void ConsoleLoad()
        {
            try
            {
                AnsiConsole.Progress()
                .Start(load =>
                {
                    var loading = load.AddTask("Loading...");

                    while (!load.IsFinished)
                    {

                        new InputParsers();
                        loading.Increment(50);
                        new Commands();
                        loading.Increment(50);
                    }
                });
            }
            catch (Exception e)
            {
                new ExceptionHandler(e,
                    Log.GetMessage("Console Load", "Something went wrong while loading " +
                    "system parsers or commands. " +
                    "Console will try run without these classes", 2));
            }
            Console.Clear();
        }
    }
}
