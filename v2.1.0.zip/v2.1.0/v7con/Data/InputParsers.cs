﻿using Spectre.Console;
using v7con;
using v7con.Data;
using v7con.ConsoleUI;
using v7con.Data.etc;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;
using System.Text.RegularExpressions;

namespace v7con.Data
{
    public partial class InputParsers
    {
        public InputParsers()
        {
            CGPC();
        }

        #region CGP

        // Common Global Parser //

        public static object? CGP = new();
        public static object? CGP_SPECTREFRIENDLY = new();
        private void CGPC()
        {
            InputParser.Parsers.Add(new InputParser()
            {
                Reference = "global",
                Description = "Default input parser.",
                HELP_ParserMethodName = "CGParser",
                ParserMethod = () =>
                {
                    CGP = Regex.Replace(AnsiConsole.Prompt(new TextPrompt<string>(
                        $"\n[bold white" +
                        $"]{Commands.GLOBALDIR.ToString().SpectreSafe()}>[/]")
                        .PromptStyle(new Style(Color.White))), @"\s+", " ");
                    CGP_SPECTREFRIENDLY = CGP.ToString().SpectreSafe();
                },

                InputProcessMethod = () =>
                {
                    string[]? Args = InputParsers.CGP!.ToString()!.Split(' ', 3);
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                        if (Args[0] == cmd.Reference)
                        {
                            if (Args.Length >= 2 && !string.IsNullOrEmpty(Args[1]))
                            {
                                if (Args[1] == "/?")
                                {
                                    new GetHelp(cmd.Reference);
                                    Main.IM.NewLine("");
                                }
                            }
                            else
                                break;
                        }
                    }
                    foreach (Command cmd in Command.CommandsRegistry)
                        cmd.Method();
                    Main.IM.NewLine("");
                }
            });
        }



        #endregion

    }
}
