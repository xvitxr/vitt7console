﻿using v7con.ConsoleUI.Debug;

namespace v7con.Data.etc
{
    public partial class GetHelp
    {
        public GetHelp(string reference, string commandSecurityMode = "/A")
        {
            foreach (Command cmd in Command.CommandsRegistry)
            {
                if (commandSecurityMode == "/A" 
                    && cmd.Reference == reference)
                {
                    if (string.IsNullOrEmpty(cmd.HELP_FullDescription)
                        && cmd.Reference == reference)
                    {
                        Log.MessageShort("Get Help Manager",
                            $"\"{reference}\" exist, but don't have a help description.", 1);
                        goto resolve;
                    }
                    Console.WriteLine(cmd.HELP_FullDescription);
                    goto resolve;
                }
                else if (!cmd.Public && commandSecurityMode == "/H"
                    && cmd.Reference == reference)
                {
                    if (string.IsNullOrEmpty(cmd.HELP_FullDescription)
                        && cmd.Reference == reference)
                    {
                        Log.MessageShort("Get Help Manager",
                            $"\"{reference}\" exist, but don't have a help description.", 1);
                        goto resolve;
                    }
                    Console.WriteLine(cmd.HELP_FullDescription);
                    goto resolve;
                }
                else if (cmd.Public && commandSecurityMode == "/P"
                    && cmd.Reference == reference)
                {
                    if (string.IsNullOrEmpty(cmd.HELP_FullDescription)
                        && cmd.Reference == reference)
                    {
                        Log.MessageShort("Get Help Manager",
                            $"\"{reference}\" exist, but don't have a help description.", 1);
                        goto resolve;
                    }
                    Console.WriteLine(cmd.HELP_FullDescription);
                    goto resolve;
                }
            }
            Log.MessageShort
                ("Get Help Manager", $"\"{reference}\" is not avaliable or not existent.");
            resolve:
            Console.Write("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
