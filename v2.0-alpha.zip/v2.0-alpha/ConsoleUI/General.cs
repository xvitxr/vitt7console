﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.ConsoleUI
{
    public class General
    {
        public General()
        {
            new InputParserMethodStorage();
            new CommandStorage();
            Console.WriteLine(Common.ConsoleManager.about);
            InputManager.NewLine("");
        }
    }
}
