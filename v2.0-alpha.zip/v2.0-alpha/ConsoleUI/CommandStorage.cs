﻿using System;
using v7con.Common;

namespace v7con.ConsoleUI
{
    public class CommandStorage
    {
        public CommandStorage()
        {
            #region NLM
            Command.CommandsRegistry.Add(new Command()
            {
                Name = "NLM",
                ShortDescription = "Manage the input line spawning (Cannot be called)",
                Reference = "nlm",
                Method = () =>
                {
                    if (string.IsNullOrEmpty(InputManager.RawInput.ToString()))
                        InputManager.NewLine("");
                }
            });
            #endregion

            #region Help Command
            // Help command //
            Command.CommandsRegistry.Add(new Command()
            {
                Name = "Help command",
                ShortDescription = "Shows informations about commands",
                FullDescription = ""
            });
            #endregion
        }
    }
}
