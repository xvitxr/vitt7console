﻿using System;
using v7con.Common;

namespace v7con.ConsoleUI
{
    public class InputManager
    {
        public static object? RawInput;
        public static void NewLine<T>(T msg)
        {
            if (!string.IsNullOrEmpty(msg.ToString()))
                Console.Write(msg);
            else
                Console.Write(">>");
            RawInput = Console.ReadLine();
            foreach (InputParser parser in InputParser.InputParsersRegistry)
            {
                parser.Method();
            }
            InputProcesser();
        }
        private static void InputProcesser()
        {
            foreach (Command command in Command.CommandsRegistry)
            {
                command.Method();
            }
        }
    }
}
