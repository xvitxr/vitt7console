﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v7con.Common
{
    public abstract class Command
    {
        public static List<Command> CommandsRegistry = new List<Command>();

        public string? Name { get; set; } = "None";

        public string? ShortDescription { get; set; } = "None";

        public string? Reference { get; set; } = "None";

        public string? Author { get; set; } = ConsoleManager.author;

        public delegate void method();

        public method? Method { get; set; }
    }
}
