﻿using System;
using System.Collections.Generic;


namespace v7con.Common
{
    public class ConsoleManager
    {

        // Variáveis do sistema / System variables
        public static string 
            name = "vitt7console",
            version = "p2.0", 
            author = "@VittSeven (GitHub)",
            about = $"{name} [version {version}] by {author}";

        public static void RunAllCommands()
        {
            foreach (Command command in Command.CommandsRegistry)
            {
                command.Method();
            }
        }

        public static void RunCommand(string reference)
        {
            foreach (Command command in Command.CommandsRegistry)
            {
                if (reference == command.Reference)
                    command.Method();
            }
        }


    }
}
