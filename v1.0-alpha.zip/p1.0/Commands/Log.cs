﻿namespace vitt7console.Commands
{
    public class Log
    {
        public Log()
        {
            Register.CommandsRegistry.Add(new Register()
            {
                Name = "Help!",
                Info = "Will show information about the avaliable commands",
                CurrMethod = () => new Avaliable.HelpMgr(),
                Syntax = "help",
                BuiltIn = true,
                Access = true,
                Reference = "help",
                Author = "@vittSeven"
            });

            Register.CommandsRegistry.Add(new Register()
            {
                Name = "Exit!",
                Reference = "exit",
                Info = "Exits the program",
                Author = "@vittSeven",
                Syntax = "exit",
                BuiltIn = true,
                Access = true,
                CurrMethod = () => new Avaliable.Exit()
            }) ;
        }
    }
}
