﻿using System;
using vitt7console.Console;

namespace vitt7console.Commands.Avaliable
{
    public class Exit
    {
        public Exit()
        {
            if (Manager.Execute("exit"))
            {
                Environment.Exit(0);
            }
        }
    }
}
