﻿using System;
using vitt7console.Console;

namespace vitt7console.Commands.Avaliable
{
    public class HelpMgr
    {
        public HelpMgr()
        {
            if (Manager.Execute("help"))
            {
                int x = 0;
                foreach (Commands.Register info in Register.CommandsRegistry)
                {
                    string isBuitIn = (info.BuiltIn) ? "yes" : "no";
                    string hasMethod = (info.CurrMethod == null) ? "no" : "yes";
                    string information =
                    $"--- '{info.Name}' by {info.Author} ---\n" +
                    $"{info.Info}\n" +
                    $"has function: {hasMethod}\n" +
                    $"Is built-in: {isBuitIn}\n" +
                    $"syntax: {info.Syntax}\n" +
                    "--- end ---\n";

                    x++;
                    System.Console.WriteLine($"{information}\n");
                }
                Manager.Input($"a total of {x} command(s)\n>>");
            }
        }
    }
}
