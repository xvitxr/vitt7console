﻿using System;
using v7con.Container.Data;
using Spectre.Console;
using v7con.ConsoleUI.Input;
using v7con.Container; 

namespace v7con.ConsoleUI
{
    public class Main
    {
        public static Manager IM = new();
        public Main()
        {
            ConsoleLoad();
            AnsiConsole.MarkupLine($"[underline cyan]{Program.about.SpectreSafe()}[/]");
            IM.NewLine("");
        }

        private static void ConsoleLoad()
        {
            AnsiConsole.Write(new FigletText("Welcome to vitt7console!")
                .Alignment(Justify.Center)
                .Color(Color.White));
            Thread.Sleep(500);
            AnsiConsole.Progress()
                .Start(load =>
                {
                    var loading = load.AddTask("Loading...");
                    while (!load.IsFinished)
                    {
                        new InputParsers();
                        loading.Increment(50);
                        new Commands();
                        loading.Increment(50);
                    }
                });
            Console.Clear();
        }
    }
}
