﻿using Spectre.Console;
using v7con.Container.Data;
namespace v7con.ConsoleUI.Debug
{
    internal class Log
    {
        private static int index = 0;
        public static string GetMessage( string? owner, string? msg, short? id = 0)
        {
            index++;
            
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;
            string idmsg = "";

            switch (id)
            {
                case 0:
                     idmsg = "INFO";
                    break;
                case 1:
                    idmsg = "WARNING";
                    break;
                case >= 2:
                    idmsg = "ERROR";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                return ($"[{index} {idmsg}]: {msg}");
            return ($"[{index} {idmsg} on \"{owner}\"]: {msg}");

        }

        public static string GetMessageShort(string? owner, string? msg, short? id = 0)
        {
            index++;
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;

            string idmsg = "";

            switch (id)
            {
                case 0:
                    idmsg = "i";
                    break;
                case 1:
                    idmsg = "w";
                    break;
                case >= 2:
                    idmsg = "e";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                return ($"[{idmsg}]: {msg}");
            return ($"[{idmsg}] {owner}: {msg}");
        }

        public static void MessageShort(string? owner, string? msg, short? id = 0)
        {
            index++;
            msg = (string.IsNullOrEmpty(msg)) ? "Something ocurred." : msg;

            string idmsg = "";

            switch (id)
            {
                case 0:
                    idmsg = "[bold blue]i[/]";
                    break;
                case 1:
                    idmsg = "[bold yellow]w[/]";
                    break;
                case >= 2:
                    idmsg = "[bold red]e[/]";
                    break;
            }

            if (string.IsNullOrEmpty(owner))
                AnsiConsole.MarkupLine($"[[{idmsg}]]: {msg.SpectreSafe()}");
            AnsiConsole.MarkupLine($"[bold white][[{idmsg}]][/] [white]" +
                $"{owner.SpectreSafe()}:[/] [bold underline white]{msg.SpectreSafe()}[/]");
        }
    }
}
