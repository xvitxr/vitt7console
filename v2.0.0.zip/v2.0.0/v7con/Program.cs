﻿using System;
using Spectre.Console;
using v7con.Container;
using v7con.ConsoleUI;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;



namespace v7con
{
    public class Program
    {
        // Variáveis do sistema / System variables
        public static string
            name = "vitt7console",
            version = "v2.0.0",
            author = "@VittSeven (GitHub)",
            about = $"{name} [version {version}] by {author}";

        static void Main()
        {
            try
            {
                new Main();
            }
            catch (Exception e)
            {
                new ExceptionHandler(e, Log.GetMessage("SYSTEM", "Something went wrong", 2));
                Console.Write("Press enter to continue...");
                Console.ReadLine();
            }
        }


    }
}
