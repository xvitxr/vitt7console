﻿using System;

namespace v7con
{
    // Provides basic information about the command / Da informação basica sobre o comando

    public partial class Command
    {
        public static List<Command> CommandsRegistry = new List<Command>();

        public string? Name { get; set; } = "None";

        public string? Description { get; set; } = "None";

        public string? Author { get; set; } = Program.author;

        public string? Reference { get; set; }

        public delegate void method();

        public method? Method { get; set; }

    }

}
