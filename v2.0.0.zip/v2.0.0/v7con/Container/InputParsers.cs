﻿using Spectre.Console;
using v7con;
using v7con.Container;
using v7con.ConsoleUI;
using v7con.Container.Data;
using v7con.ConsoleUI.Input;
using v7con.ConsoleUI.Debug;

namespace v7con.Container
{
    public partial class InputParsers
    {
        public InputParsers()
        {
            CGPC();
        }

        #region CGP

        // Common Global Parser //

        public static object? CGP = new();
        public static object? CGP_SPECTREFRIENDLY = new();
        private void CGPC()
        {
            InputParser.Parsers.Add(new InputParser()
            {
                Reference = "global",
                Description = "Default Input Parser, simple parsing, Console.ReadLine() => CGP",
                HELP_ParserMethodName = "CGParser",
                ParserMethod = () =>
                {
                    CGP = AnsiConsole.Prompt(new TextPrompt<string>(
                        $"\n[bold white" +
                        $"]{Commands.GLOBALDIR.ToString().SpectreSafe()}>[/]")
                        .PromptStyle(new Style(Color.White)));
                    CGP_SPECTREFRIENDLY = CGP.ToString().SpectreSafe();
                },

                InputProcessMethod = () =>
                {
                    foreach (Command cmd in Command.CommandsRegistry)
                    {
                            cmd.Method();
                    }
                    Main.IM.NewLine("");
                }
            });
        }



        #endregion

    }
}
